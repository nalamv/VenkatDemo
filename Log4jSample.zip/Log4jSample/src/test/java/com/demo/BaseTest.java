package com.demo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class BaseTest {
	static{
		//System.setProperty("log4j.configurationFile", "log4j2.properties");
	}


	public ExtentReports extent; // For the report itself
	private static final Logger logger = LogManager.getLogger(BaseTest.class);
	public ExtentTest test;
	
	@BeforeSuite
	public void setupLog4j() {
		logger.info("Log4j configuration initialized.");
		ExtentSparkReporter htmlReporter = new ExtentSparkReporter("extent-reports/ExtentReport.html");
		htmlReporter.config().setTheme(Theme.DARK); // Theme can be DARK or STANDARD
		htmlReporter.config().setDocumentTitle("Automation Test Report");
		htmlReporter.config().setReportName("Selenium Test Suite Report");


		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);

		// Add additional system information to the report
		extent.setSystemInfo("Tester", "Your Name");
		extent.setSystemInfo("Environment", "QA");
		extent.setSystemInfo("Browser", "Chrome");
	}
	
	@AfterSuite
	public void afterSuite() {
		System.out.println("Report Flushed");
		extent.flush();
	}
}
