package com.demo;

import java.nio.file.Paths;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;

public class Myclass {
	private static final Logger logger = LogManager.getLogger(Myclass.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// System.setProperty("log4j.configurationFile", "log4j2.properties");
		// Configurator.initialize(null,Paths.get("log4j2.properties").toAbsolutePath().toString());
	        // Logging example
	        logger.info("Log4j custom configuration loaded successfully.");
	        logger.debug("This is a debug message.");
	        System.out.println("Hello");
	}

}
