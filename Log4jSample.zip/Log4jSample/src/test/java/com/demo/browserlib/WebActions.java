package com.demo.browserlib;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebActions {


	@FindBy(xpath="//span[.='Practice Form']/ancestor::div[@class='element-list collapse show']")
	WebElement PRACTICE_FORM_SHOW;




	public boolean verifyElementIsVisible(WebDriver driver,WebElement element) {
		try {
			WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(1));
			if(wait.until(ExpectedConditions.visibilityOf(element))!=null) {
				return true;
			}
		}catch(NoSuchElementException e) {
			return false;
		}
		return false;   
	}




	public void elementClick(WebDriver driver, WebElement element) {
		
		
	}

}
