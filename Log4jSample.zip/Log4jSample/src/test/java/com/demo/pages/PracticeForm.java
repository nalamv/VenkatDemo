package com.demo.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.demo.BaseTest;
import com.demo.Test1;
import com.demo.browserlib.WebActions;

public class PracticeForm extends BaseTest{

	
	 private static final Logger logger = LogManager.getLogger(PracticeForm.class);
	    WebDriver driver;

	
	    @FindBy(xpath="//span[.='Practice Form']/ancestor::div[@class='element-list collapse show']")
		WebElement PRACTICE_FORM_SHOW;
	    
	    @FindBy(xpath="//span[.='Practice Form']")
	    WebElement PRATICEFORM_LINK;
	    
	       // For logging individual test information
	
	public void OpenPraticeForm() {
		logger.info("Navigating to Demo QA.");
        test.info("Navigating to Demo QA.");
        driver.get("https://demoqa.com/forms");
        logger.debug("Page title: " + driver.getTitle());
        test.pass("Page title: " + driver.getTitle());
        
         WebActions web=PageFactory.initElements(driver, WebActions.class);
         if(web.verifyElementIsVisible(driver, PRACTICE_FORM_SHOW)) {
        	 logger.debug("Practice for is expanded");
        	PRATICEFORM_LINK.click();
         }else {
        	 logger.debug("Practice form is not expanded");
         }
	}
	
}
