package com.demo;

import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.demo.browserlib.WebActions;
import com.demo.pages.PracticeForm;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test1 extends BaseTest{
	 private static final Logger logger = LogManager.getLogger(Test1.class);
	    WebDriver driver;

	
	    @FindBy(xpath="//span[.='Practice Form']/ancestor::div[@class='element-list collapse show']")
		WebElement PRACTICE_FORM_SHOW;
	    
	    @FindBy(xpath="//span[.='Practice Form']")
	    WebElement PRATICEFORM_LINK;
	    
	          // For logging individual test information
	
	    @BeforeClass
	    public void setUp() {
	    	
	    	logger.info("Setting up WebDriver and initializing the test.");
	        test=extent.createTest("Google test case");
	    	WebDriverManager.chromedriver().arch64().setup();
	        driver = new ChromeDriver();
	        logger.debug("WebDriver initialized.");
	        test.info("WebDriver initialized.");
	    }

	    @Test
	    public void openGoogle() {
	        PracticeForm practiceForm=PageFactory.initElements(driver, PracticeForm.class);
	        practiceForm.OpenPraticeForm();
	    }

	    @AfterClass
	    public void tearDown() {
	        logger.info("Closing the browser.");
	        if (driver != null) {
	            driver.quit();
	        }
	        logger.debug("Test completed.");
	        test.info("Test completed.");
	        extent.flush();
	    }
	
}
